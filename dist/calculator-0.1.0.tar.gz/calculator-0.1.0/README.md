# Calculator Package

A simple Python calculator package for basic arithmetic operations.

## Features
- Addition
- Subtraction
- Multiplication
- Division

## Installation

```bash
pip install calculator